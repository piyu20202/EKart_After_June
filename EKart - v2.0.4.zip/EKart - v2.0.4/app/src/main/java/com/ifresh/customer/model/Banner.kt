package com.ifresh.customer.model

class Banner {
    var banner_img:String? = null
    var banner_title:String? = null

}