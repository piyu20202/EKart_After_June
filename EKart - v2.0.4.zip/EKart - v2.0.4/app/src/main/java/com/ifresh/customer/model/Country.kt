package com.ifresh.customer.model

class Country
{
    var country_name:String? = null
    var country_id:String?=null

}