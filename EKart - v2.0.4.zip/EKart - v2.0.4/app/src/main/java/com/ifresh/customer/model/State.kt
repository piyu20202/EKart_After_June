package com.ifresh.customer.model

class State {

    var state_name:String? = null
    var state_id:String?=null

}