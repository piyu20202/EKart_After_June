package com.ifresh.customer.helper;

public class Config {
    // Google Console APIs developer key
    // Replace this key with your's
    public static final String DEVELOPER_KEY = "AIzaSyBigzFJ6ag5E7pgeCdvpZbig7vKPYSUGx0";
    //public static final String DEVELOPER_KEY = "AIzaSyBigzFJ6ag5E7pgeCdvpZbig7vKPYSUGx0";



    // YouTube video id
    public static final String YOUTUBE_VIDEO_CODE = "pr-4GbR4DpQ";
}
