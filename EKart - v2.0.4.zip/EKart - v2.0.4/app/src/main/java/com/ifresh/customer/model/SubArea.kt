package com.ifresh.customer.model

class SubArea {

    var subarea_name:String? = null
    var subarea_id:String?=null
}