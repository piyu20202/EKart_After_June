package com.ifresh.customer.model

class Area {

    var area_name:String? = null
    var area_id:String?=null

}