package com.ifresh.customer.model

class AddressType
{
    var address_type:String? = null
    var adress_id:String? = null
}