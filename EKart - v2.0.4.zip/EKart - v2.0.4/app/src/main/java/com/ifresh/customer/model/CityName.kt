package com.ifresh.customer.model

class CityName {
    var city_name:String? = null
    var city_id:String?=null

}